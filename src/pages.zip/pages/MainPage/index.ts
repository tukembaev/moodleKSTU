import { MainPageAsync as MainPage }  from "./ui/MainPage.async";

export {
    MainPage,
};
