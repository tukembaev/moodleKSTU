import { lazy } from "react";

export const AboutUsPageAsync = lazy(() => import("./AboutUsPage"));
