import { lazy } from "react";

export const CategoryPageAsync = lazy(() => import("./CategoryPage"));
