import { lazy } from "react";

export const NotificationPageAsync = lazy(() => import("./NotificationPage"));
