import { addToCart } from "./addToCard";

export {addToCart}