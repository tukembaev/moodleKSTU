export interface ProfilePayload {
  avatar?: string,
  // email: string,
  bio?: string,
  number_phone?: string,
  telegram_username?: string
  }

export interface FavoritePayload {
    theme?:string;
    course?:string
  }