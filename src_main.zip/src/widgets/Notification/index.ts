import NotificationDetail from "./ui/NotificationDetail";
import NotificationList from "./ui/NotificationList";

export {
  NotificationDetail,
  NotificationList,
};