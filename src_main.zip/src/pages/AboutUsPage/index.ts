import { AboutUsPageAsync } from "./ui/AboutUsPage.async";

export {AboutUsPageAsync as AboutUsPage}