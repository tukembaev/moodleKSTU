import { lazy } from "react";

export const QuizTestPageAsync = lazy(() => import("./QuizTestPage"));

