export { QuizResultsPageAsync as QuizResultsPage } from "./ui/QuizResultsPage.async";

