import { lazy } from "react";

export const QuizResultsPageAsync = lazy(() => import("./QuizResultsPage"));

