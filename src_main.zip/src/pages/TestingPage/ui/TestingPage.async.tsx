import { lazy } from "react";

export const TestingPageAsync = lazy(() => import("./TestingPage"));

