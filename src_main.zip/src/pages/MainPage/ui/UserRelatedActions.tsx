const UserRelatedActions = () => {
  return <div>UserRelatedActions</div>;
};

export default UserRelatedActions;
