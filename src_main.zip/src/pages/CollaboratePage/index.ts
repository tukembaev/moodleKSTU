import { CollaboratePageAsync } from "./ui/CollaborateAsyncPage";

export {CollaboratePageAsync as CollaboratePage}