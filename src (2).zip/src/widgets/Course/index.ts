import HighRatedCourseCarousel from "./BrowseCourse/HighRatedCourseCarousel";
import BrowseCourse from "./BrowseCourse/SearchCourse";
import UrgentWorkWidget from "./CourseThemeWidgets/UrgentWorkWidget";


export {UrgentWorkWidget ,BrowseCourse, HighRatedCourseCarousel};