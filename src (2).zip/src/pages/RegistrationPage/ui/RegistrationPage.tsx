import { RegistrationList } from "features/Course";

const RegistrationPage = () => {
  return (
    <div>
      <RegistrationList />
    </div>
  );
};

export default RegistrationPage;
