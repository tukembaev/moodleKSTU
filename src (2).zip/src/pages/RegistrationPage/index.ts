import RegistrationPage from "./ui/RegistrationPage";

export {RegistrationPage}