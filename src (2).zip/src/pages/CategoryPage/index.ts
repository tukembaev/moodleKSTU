import { CategoryPageAsync } from "./ui/CategoryPageAsync";

export {CategoryPageAsync as CategoryPage}