import { TestingPageAsync as TestingPage } from "./ui/TestingPage.async";

export { TestingPage }