import { CoursePageAsync } from "./ui/CoursePage.async";

export {CoursePageAsync as CoursePage}