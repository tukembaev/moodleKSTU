import { lazy } from "react";

export const CoursePageAsync = lazy(() => import("./CoursePage"));
