import { UniversitiesPageAsync as UniversitiesPage }  from "./ui/UniversitiesPage.async";

export {
    UniversitiesPage,
};
