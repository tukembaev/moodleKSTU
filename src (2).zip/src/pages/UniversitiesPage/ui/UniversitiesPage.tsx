import { UniversityList } from "entities/University";

const UniversitiesPage = () => {
  return (
    <div>
      <UniversityList />
    </div>
  );
};

export default UniversitiesPage;
