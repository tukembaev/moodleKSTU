export { QuizTestPageAsync as QuizTestPage } from "./ui/QuizTestPage.async";

