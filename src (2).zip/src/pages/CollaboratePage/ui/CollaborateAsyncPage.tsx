import { lazy } from "react";

export const CollaboratePageAsync = lazy(() => import("./CollaboratePage"));
