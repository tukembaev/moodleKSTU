import { ChatPageAsync } from "./ui/ChatPageAsync";

export {ChatPageAsync as ChatPage}