import { lazy } from "react";

export const StatisticPageAsync = lazy(() => import("./StatisticPage"));
