import { StatisticPageAsync } from "./ui/StatisticPage.async";

export { StatisticPageAsync as StatisticPage };