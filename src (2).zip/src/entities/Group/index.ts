import GroupDetail from "./ui/GroupDetail";
import GroupList from "./ui/GroupList";

export {GroupList , GroupDetail}