



export const groupQueries = {

  // allGroup: (id: number | null) =>
  //   queryOptions({
  //     queryKey: ['course','?owner_id=', id],
  //     queryFn: () => getGroup(id as number),
  //     enabled: !!id,
  //   }),

    // allTasks: (id: number | null) =>
    //   queryOptions({
    //     queryKey: ['course','?course=', id],
    //     queryFn: () => getCourseAllTasks(id as number),
    //     enabled: !!id,
    //   }),
  
    // allTaskMaterials: (id: number | null) =>
    //     queryOptions({
    //       queryKey: ['course', id],
    //       queryFn: () => getTaskMaterials(id as number),
    //       enabled: !!id,
    //     }),
    


};
