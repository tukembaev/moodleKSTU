import GoogleIcon from "./icons/GoogleIcon";

export { GoogleIcon }; 