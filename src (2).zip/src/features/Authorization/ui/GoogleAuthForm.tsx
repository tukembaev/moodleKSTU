// import { useGoogleToken } from "../lib/useGoogleToken";

// export const GoogleAuthForm = () => {
//   const { token, loading } = useGoogleToken({
//     clientId:
//       "1082367956142-ntu3usf4p07jpd1enjn7gj308a95qn4v.apps.googleusercontent.com",
//     scope: ["https://www.googleapis.com/auth/calendar", "openid", "email"],
//   });

//   if (token) {
//     return <p className="text-green-500">Успешная авторизация! Токен: as</p>;
//   }

//   if (loading) {
//     return <p>Перенаправляем на Google OAuth…</p>;
//   }

//   return null;
// };
