# Deployment Guide - Chat Feature

## Быстрый старт

Чат полностью готов к использованию! Все необходимые файлы созданы и интегрированы.

### 1. Проверка зависимостей

Все необходимые зависимости уже установлены в проекте:

```json
{
  "dependencies": {
    "axios": "^1.7.9",
    "sonner": "^2.0.1",
    "date-fns": "^3.6.0",
    "lucide-react": "^0.475.0",
    "react": "^19.0.0"
  },
  "devDependencies": {
    "@tanstack/react-query": "^5.66.8"
  }
}
```

### 2. Использование в приложении

```tsx
import { ChatContainer } from "features/Chat";

function App() {
  return (
    <div>
      <ChatContainer />
    </div>
  );
}
```

### 3. Настройка API URLs (если требуется)

Если ваш API находится на другом домене, обновите URLs в файлах:

**`src/features/Chat/model/services/chatAPI.ts`**:
```typescript
export const CHAT_API_URL = `https://your-domain.com/api/unet-chat/`;
```

**`src/features/Chat/lib/useWebSocket.tsx`**:
```typescript
const WS_BASE_URL = "wss://your-domain.com/api/unet-chat/ws";
```

## Структура файлов

```
src/features/Chat/
├── model/
│   ├── types/
│   │   └── chat.ts              # TypeScript типы
│   └── services/
│       ├── chatAPI.ts           # REST API сервис
│       └── chatQueries.ts       # React Query hooks
├── lib/
│   ├── useWebSocket.tsx         # WebSocket хук
│   └── constants.ts             # Константы
├── ui/
│   ├── ChatContainer.tsx        # Главный контейнер ✓
│   ├── ChatMessages.tsx         # Компонент сообщений ✓
│   └── ChatSelect.tsx           # Список бесед ✓
├── index.ts                     # Экспорты
├── README.md                    # Документация
├── EXAMPLE.md                   # Примеры использования
└── DEPLOYMENT.md                # Руководство по развертыванию
```

## Функционал

### ✅ Реализовано

1. **REST API интеграция**
   - ✅ Создание бесед (POST /conversations/)
   - ✅ Получение списка бесед (GET /conversations/)
   - ✅ Получение беседы по ID (GET /conversations/{id})
   - ✅ Удаление бесед (DELETE /conversations/{id})
   - ✅ Отправка сообщений (POST /messages/)
   - ✅ Получение сообщений (GET /messages/{conversation_id})
   - ✅ Редактирование сообщений (PUT /messages/{message_id})
   - ✅ Удаление сообщений (DELETE /messages/{message_id})
   - ✅ Добавление участников (POST /conversations/{id}/participants/)
   - ✅ Удаление участников (DELETE /conversations/{id}/participants/{user_id})

2. **WebSocket интеграция**
   - ✅ Подключение к WebSocket
   - ✅ Отправка сообщений в реальном времени
   - ✅ Получение сообщений в реальном времени
   - ✅ Автоматическое переподключение
   - ✅ Обработка ошибок
   - ✅ Индикация статуса подключения

3. **UI Компоненты**
   - ✅ ChatContainer - главный контейнер
   - ✅ ChatMessages - список сообщений с WebSocket
   - ✅ ChatSelect - список бесед с поиском
   - ✅ Адаптивный дизайн
   - ✅ Toast уведомления
   - ✅ Индикаторы загрузки

4. **Дополнительно**
   - ✅ React Query интеграция
   - ✅ TypeScript типизация
   - ✅ Автоматическое обновление токена
   - ✅ Обработка ошибок 401
   - ✅ Константы и конфигурация

## Тестирование

### 1. Тест создания беседы

```typescript
import { createConversation, getCurrentUserId } from "features/Chat";

const testCreateConversation = async () => {
  try {
    const conversation = await createConversation({
      type: "group",
      title: "Тестовая группа",
      participant_ids: [getCurrentUserId()!],
    });
    console.log("✅ Беседа создана:", conversation);
  } catch (error) {
    console.error("❌ Ошибка создания беседы:", error);
  }
};
```

### 2. Тест WebSocket подключения

```typescript
import { useWebSocket } from "features/Chat";

const { isConnected, sendMessage } = useWebSocket({
  conversationId: "YOUR_CONVERSATION_ID",
  onMessage: (msg) => console.log("📩 Получено:", msg),
  onOpen: () => console.log("✅ WebSocket подключен"),
  onError: (err) => console.error("❌ WebSocket ошибка:", err),
});

// Отправить тестовое сообщение
if (isConnected) {
  sendMessage("Тестовое сообщение");
}
```

### 3. Тест загрузки бесед

```typescript
import { getConversations } from "features/Chat";

const testGetConversations = async () => {
  try {
    const conversations = await getConversations();
    console.log("✅ Беседы загружены:", conversations.length);
  } catch (error) {
    console.error("❌ Ошибка загрузки бесед:", error);
  }
};
```

## Аутентификация

Чат использует JWT токен из localStorage:

```typescript
const auth_data = JSON.parse(localStorage.getItem("auth_data") || "{}");
const token = auth_data.access;
const userId = auth_data.user_id;
```

### Формат auth_data:

```json
{
  "access": "JWT_ACCESS_TOKEN",
  "refresh": "JWT_REFRESH_TOKEN",
  "user_id": 123
}
```

## API Endpoints

### Base URLs

- **REST API**: `https://uadmin.kstu.kg/api/unet-chat/`
- **WebSocket**: `wss://uadmin.kstu.kg/api/unet-chat/ws`

### Заголовки

Все REST запросы используют заголовок:
```
WWW-Authenticate: Bearer <JWT_TOKEN>
```

WebSocket использует query параметр:
```
?WWW-Authenticate=Bearer%20<JWT_TOKEN>
```

## Troubleshooting

### Проблема: WebSocket не подключается

**Решение:**
1. Проверьте токен в localStorage
2. Убедитесь, что пользователь является участником беседы
3. Проверьте консоль браузера на ошибки

```typescript
// Проверка токена
const token = getAuthToken();
console.log("Token:", token);

// Проверка ID пользователя
const userId = getCurrentUserId();
console.log("User ID:", userId);
```

### Проблема: Ошибка 401 Unauthorized

**Решение:**
Токен автоматически обновляется через `refreshUser()`. Если ошибка повторяется:
1. Проверьте refresh токен
2. Перезайдите в систему
3. Очистите localStorage

### Проблема: Сообщения не отправляются

**Решение:**
1. Проверьте статус WebSocket подключения
2. Убедитесь, что текст сообщения не пустой
3. Проверьте права доступа к беседе

```typescript
const { isConnected, error } = useWebSocket({ conversationId });
console.log("Connected:", isConnected);
console.log("Error:", error);
```

### Проблема: Старые сообщения не загружаются

**Решение:**
Проверьте параметры пагинации:

```typescript
const messages = await getMessages(conversationId, 50, 0);
// limit: 50, offset: 0
```

## Производительность

### Оптимизация

1. **React Query кеширование** - автоматическое
2. **WebSocket переподключение** - максимум 5 попыток
3. **Пагинация сообщений** - по 50 сообщений
4. **Дедупликация сообщений** - проверка по ID

### Рекомендации

- Используйте React Query hooks вместо прямых API вызовов
- Ограничивайте количество одновременных WebSocket подключений
- Используйте пагинацию для больших списков сообщений
- Закрывайте WebSocket соединения при размонтировании компонентов

## Безопасность

1. ✅ JWT токен в заголовках/query параметрах
2. ✅ Автоматическое обновление токена
3. ✅ Проверка прав доступа на сервере
4. ✅ Валидация данных

## Дополнительные ресурсы

- **README.md** - основная документация
- **EXAMPLE.md** - примеры использования
- **API Documentation** - полная документация API (предоставлена пользователем)

## Контакты и поддержка

При возникновении проблем:
1. Проверьте консоль браузера
2. Проверьте сетевые запросы в DevTools
3. Проверьте формат данных в localStorage
4. Изучите примеры в EXAMPLE.md

---

**Статус:** ✅ Полностью готово к использованию

**Версия:** 1.0.0

**Последнее обновление:** December 2024
