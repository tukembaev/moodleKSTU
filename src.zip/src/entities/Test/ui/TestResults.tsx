import { useQuery } from "@tanstack/react-query";
import TestTable from "./lib/TestTable";
import { testQueries } from "../model/services/testQueryFactory";
import { useParams } from "react-router-dom";

const TestResults = () => {
  const { id } = useParams();
  const { data: test_list, isLoading } = useQuery(
    testQueries.TestResult(id as string)
  );
  console.log(test_list);
  return (
    <div className="min-h-screen flex py-3 flex-col gap-4">
      <div className="w-full">
        <div className="flex flex-col">
          <span className="text-4xl sm:text-5xl font-bold tracking-tight">
            Лучший тест
          </span>
          <p className=" text-lg text-muted-foreground pt-4">
            Максимум баллов за тест: 12
          </p>
          <p className="text-lg text-muted-foreground pt-1">
            Дедлайн сдачи: 12 апреля 2025
          </p>
        </div>
      </div>
      <TestTable max_point={20} />
    </div>
  );
};

export default TestResults;
