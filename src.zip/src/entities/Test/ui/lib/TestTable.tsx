import { LuCheckCheck, LuX } from "react-icons/lu";
import { Avatar, AvatarImage } from "shared/shadcn/ui/avatar";
import { Badge } from "shared/shadcn/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "shared/shadcn/ui/table";

const TestTable = ({ max_point = 22 }: { max_point: number }) => {
  const data = [
    {
      id: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
      avatar:
        "https://imageio.forbes.com/specials-images/imageserve/6726c1f22bd2d18763201440/0x0.jpg?format=jpg&crop=1334,1335,x582,y227,safe&height=416&width=416&fit=bounds",
      status: true,
      points: 12,
      fullname: "Тайла Косятникова",
      group: "ПИ-21",
      user_id: 0,
      result: 2147483647,
    },
  ];
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader className="bg-muted">
          <TableRow className="hover:bg-transparent ">
            <TableHead className="w-[300px]">Имя студента</TableHead>
            <TableHead className="w-[100px]">Группа</TableHead>
            <TableHead className="w-[100px]">Баллы</TableHead>
            <TableHead className="w-[130px]">Статус сдачи</TableHead>
            {/* <TableHead>Доступ</TableHead> */}
            <TableHead />
          </TableRow>
        </TableHeader>

        <TableBody>
          {data.map((student) => (
            <>
              <TableRow key={student.id}>
                <TableCell className="font-medium flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={student.avatar} />
                  </Avatar>
                  <p>{student.fullname}</p>
                </TableCell>
                <TableCell>{student.group}</TableCell>
                <TableCell>
                  {student.points} / {max_point}
                </TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className="flex gap-1 px-1.5 text-muted-foreground [&_svg]:size-3 "
                  >
                    {student.status ? (
                      <LuCheckCheck className="text-green-500 dark:text-green-400" />
                    ) : (
                      <LuX />
                    )}
                    {student.status ? "Сдано" : "Не сдано"}
                  </Badge>
                </TableCell>
                {/* 
                <TableCell
                  colSpan={6}
                  className="flex justify-end cursor-pointer"
                >
                  <span>as</span>
                </TableCell> */}
              </TableRow>
            </>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default TestTable;
