import React, { useEffect, useState } from "react";

import { MessageCircle, ThumbsUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Avatar, AvatarImage } from "shared/shadcn/ui/avatar";
import { Button } from "shared/shadcn/ui/button";
import { Textarea } from "shared/shadcn/ui/textarea";

export type FeedItem = {
  id: string;
  user: {
    user_id: number;
    name: string;
    avatar: string;
  };
  content: string;
  timestamp: string;
  replies?: FeedItem[];
  likes?: number;
  onReply?: (id: string, message: string) => void;
  onLike?: (id: string) => void;
};

type FeedProps = {
  items: FeedItem[];
  depth?: number; // depth — уровень вложенности. 0 — корневой, 1+ — ответы на комментарии
};

export const Feed: React.FC<FeedProps> = ({ items, depth = 0 }) => {
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState<string>("");
  const navigate = useNavigate();
  useEffect(() => {
    console.log(replyingTo, replyText);
  }, [replyingTo, replyText]);
  return (
    <ul className={`ml-${depth > 0 ? 2 : 0} space-y-4 relative mt-2 `}>
      {items.map((item) => (
        <li key={item.id} className="relative">
          <div>
            <div className="flex gap-3 ">
              <Avatar
                className="w-8 h-8 cursor-pointer "
                onClick={() => navigate(`/profile/${item.user.user_id}`)}
              >
                <AvatarImage
                  src={item.user.avatar}
                  alt={item.user.name}
                  className="object-cover"
                />
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span
                    className="font-medium text-sm cursor-pointer hover:text-orange-300"
                    onClick={() => navigate(`/profile/${item.user.user_id}`)}
                  >
                    {item.user.name}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {item.timestamp}
                  </span>
                </div>
                <p className="text-sm  mt-1 whitespace-pre-wrap">
                  {item.content}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setReplyingTo(replyingTo === item.id ? null : item.id)
                    }
                    className="flex items-center gap-1 text-xs px-0"
                  >
                    <MessageCircle className="w-4 h-4" /> Ответить
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => item.onLike?.(item.id)}
                    className="flex items-center gap-1 text-xs px-0"
                  >
                    <ThumbsUp className="w-4 h-4" /> Полезно ({item.likes || 0})
                  </Button>
                </div>

                {replyingTo === item.id && (
                  <div className="mt-3">
                    <Textarea
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="Напиши свой ответ..."
                      className="text-sm"
                    />
                    <div className="mt-2 flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => {
                          if (replyText.trim()) {
                            item.onReply?.(item.id, replyText);
                            setReplyText("");
                            setReplyingTo(null);
                          }
                        }}
                      >
                        Отправить
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setReplyingTo(null);
                          setReplyText("");
                        }}
                      >
                        Отмена
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {item.replies && item.replies.length > 0 && (
            <div
              className="mt-4 ml-10 relative"
              style={{ borderLeft: "1px solid #e2e8f0" }}
            >
              <Feed items={item.replies} depth={depth + 1} />
            </div>
          )}
        </li>
      ))}
    </ul>
  );
};
