import { queryOptions } from '@tanstack/react-query';

import { deleteCourse, editCourseDetails, getAnswerTask, getCourseAllTasks, getCoursesOfProfessor, getCourseTablePerfomance, getStudentAnswers, getTaskMaterials, getThemeFAQ } from './courseAPI';

import { useChangePermission, useCreateAnswer, useCreateCourse, useCreateFAQ, useCreateMaterial, useCreateTheme, useFinishCourse, useRateAnswerAndComment } from 'features/Course/model/services/course_queries';




export const courseQueries = {
  //----------GET QUERIES------------
  allCourses: () =>
    queryOptions({
      queryKey: ['course'],
      queryFn: () => getCoursesOfProfessor(),
    }),
    allTasks: (id: string | null) =>
      queryOptions({
        queryKey: ['course','course-theme',id],
        queryFn: () => getCourseAllTasks(id as string),
        enabled: !!id,
        
      }),
    allTaskMaterials: (id: string | null) =>
        queryOptions({
          queryKey: ['course','course-details'],
          queryFn: () => getTaskMaterials(id as string),
          enabled: !!id,
        }),
    allAnswerTask: (id: string | null) =>
          queryOptions({
            queryKey: ['answer-task'],
            queryFn: () => getAnswerTask(id as string),
            enabled: !!id,
          }),
    allStudentAnswers: (id: string | null) =>
            queryOptions({
              queryKey: ['student-answer-task'],
              queryFn: () => getStudentAnswers(id as string),
              enabled: !!id,
            }),
      allStudentPerfomance: (id: string | null) =>
              queryOptions({
                queryKey: ['table-perfomance',id],
                queryFn: () => getCourseTablePerfomance(id as string),
                enabled: !!id,
              }),
    allThemeFAQ: (theme: string | null) =>
              queryOptions({
                queryKey: ['faq',theme],
                queryFn: () => getThemeFAQ(theme as string),
                enabled: !!theme,
              }),
  
  //----------POST QUERIES------------
      
  create_course: () => useCreateCourse(),
  create_theme: () => useCreateTheme(),
  create_faq: () => useCreateFAQ(),
  create_material: () => useCreateMaterial(),
  create_answer: () => useCreateAnswer(),
  rate_answer: () => useRateAnswerAndComment(),
  finish_course: () => useFinishCourse(),

  edit_permission: () => useChangePermission(),

  


  editCourse: (id: number, data: any) => editCourseDetails(id, data),

  deleteCourse: (id: number) => deleteCourse(id),

};
