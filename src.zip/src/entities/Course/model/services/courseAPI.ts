import { CreateCoursePayload, CreateFAQPayload, CreateThemePayload, editPermissionPayload } from "features/Course";
import $api_edu from "shared/api/api_edu";
import $api_users from "shared/api/api_users";
import { Course, CourseMaterials, CourseThemes, FileAnswer, StudentsAnswers, TablePerfomance, ThemeFaq } from "../types/course";
import { ExtraPointPayload, FinishCoursePayload, RateAnswerPayload } from "features/Course/model/types/course_payload";



//Все курсы/дисциплины преподавателя
export const getCoursesOfProfessor = async ():Promise<Course[]> => {
    const response = await $api_users.get(`my-courses`); 
    return response.data;
  };
//Все задания выбранной дисциплины
  export const getCourseAllTasks = async (id: string | null):Promise<CourseThemes> => {
    const response = await $api_edu.get(`course-theme/${id}`); 
    return response.data;
  };
//Все уроки и материалы выбранного задани
export const getTaskMaterials = async (id: string | null):Promise<CourseMaterials[]> => {
  const response = await $api_edu.get(`course-detail/${id}`); 
  return response.data.data;
};
export const getAnswerTask = async (id: string | null):Promise<StudentsAnswers[]> => {
  const response = await $api_edu.get(`answer-task/${id}`); 
  return response.data;
};
export const getStudentAnswers = async (id: string | null):Promise<FileAnswer[]> => {
  const response = await $api_edu.get(`student-task-files/${id}`); 
  return response.data;
};
export const getThemeFAQ = async (theme: string | null):Promise<ThemeFaq[]> => {
  const response = await $api_edu.get(`faq/${theme}`); 
  return response.data;
};
export const getCourseTablePerfomance = async (id: string | null):Promise<TablePerfomance[]> => {
  const response = await $api_edu.get(`table-performance/${id}`); 
  return response.data;
};
export const createCourse = async (data:CreateCoursePayload) => {
  const response = await $api_edu.post(`course/`,data); 
  return response.data;
};
export const createTheme = async (data:CreateThemePayload) => {
  const response = await $api_edu.post(`course-detail/`,data); 
  return response.data;
};
export const createFAQ = async (data:CreateFAQPayload) => {
  const response = await $api_edu.post(`faq/`,data); 
  return response.data;
};
export const createMaterial = async (data: FormData) => {
  const response = await $api_edu.post(`material/`, data, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
};
export const createAnswer = async (data: FormData) => {
  const response = await $api_edu.post(`answer-task/`, data, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });

  return response.data;
};

export const makeIsRead = async (file:string) => {
  const response = await $api_edu.post(`is_read-file/`,{file:file}); 
  return response.data;
};
export const rateTheAnswerAndComment = async (data:RateAnswerPayload) => {
  const response = await $api_edu.post(`scoring/`,data); 
  return response.data;
};
export const editPermissionTheme = async (id:string,data:editPermissionPayload) => {
  const response = await $api_edu.patch(`partial-locked-task/${id}/`,data); 
  return response.data;
};

export const editCourseDetails = async (id: number | null , data: any) => {
  const response = await $api_edu.patch(`course/${id}`, data); 
  return response.data;
};
export const deleteCourse = async (id: number | null) => {
  const response = await $api_edu.delete(`course/${id}`); 
  return response.data;
};
export const finishCourse = async (data:FinishCoursePayload) => {
  const response = await $api_edu.post(`finish-course/`,data); 
  return response.data;
};
export const setExtraPoints = async (data:ExtraPointPayload) => {
  const response = await $api_edu.post(`extra-points/`,data); 
  return response.data;
};