import { useQuery } from "@tanstack/react-query";
import { userQueries } from "entities/User";
import { ChevronRight } from "lucide-react";
import {
  LuBookCheck,
  LuBookmark,
  LuCheckCheck,
  LuPlus,
  LuStar,
} from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import {
  CategoryBar,
  CourseStatisticTooltip,
  FadeIn,
  FadeInList,
  HoverLift,
  HoverScale,
  SpringPopupList,
  UseTooltip,
} from "shared/components";
import { AppRoutes, AppSubRoutes, FormQuery } from "shared/config";
import { Avatar, AvatarImage } from "shared/shadcn/ui/avatar";
import { Button } from "shared/shadcn/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "shared/shadcn/ui/select";
import CourseCardSkeleton from "../lib/skeletons/CourseCardSkeleton";
import { courseQueries } from "../model/services/courseQueryFactory";
import { useAuth, useForm } from "shared/hooks";
import { Badge } from "shared/shadcn/ui/badge";

const CourseList = () => {
  const { isStudent } = useAuth();
  const navigate = useNavigate();
  const openForm = useForm();
  const { data, isLoading, error } = useQuery(courseQueries.allCourses());
  const { mutate: make_favorite } = userQueries.make_favorite();
  const { mutate: delete_favorite } = userQueries.delete_favorite();

  return (
    <div className="min-h-screen flex py-3 ">
      <div className="w-full">
        <div className="flex justify-between items-center">
          <div className="flex flex-col">
            <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight text-left">
              Мои курсы
            </h2>
            <p className="mt-1.5 text-lg text-muted-foreground">
              Все курсы, которые вы сохраняли или загружали
            </p>
          </div>

          <Select defaultValue="recommended">
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recommended">Мои курсы</SelectItem>
              <SelectItem value="popular">Все курсы</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mx-auto">
          {isLoading ? (
            <SpringPopupList>
              {Array.from({ length: 5 }).map((_, index) => (
                <CourseCardSkeleton key={index} />
              ))}
            </SpringPopupList>
          ) : error ? (
            <p>Произошла непредвиденная ошибка! {error.message} </p>
          ) : (
            <FadeInList>
              {data?.map((course) => (
                <div
                  key={course.id}
                  className="flex flex-col border rounded-xl py-4 px-5 justify-between min-w-1/3"
                >
                  <div>
                    <div className="flex justify-between">
                      <div className="flex gap-2 items-center pb-2">
                        <Badge
                          variant={"outline"}
                          className="max-h-6 flex gap-2 pr-3"
                        >
                          <img
                            src={course.category_icon}
                            className="w-4"
                            alt=""
                          />
                          {course.category}
                        </Badge>
                        <UseTooltip text="Количество отзывов: 500" side="right">
                          <span className="text-muted-foreground text-sm flex gap-1 items-center max-w-10 ">
                            <LuStar
                              className="fill-amber-200 text-amber-200 "
                              size={18}
                            />{" "}
                            4.3
                          </span>
                        </UseTooltip>
                      </div>

                      <HoverScale>
                        {course.is_favorite ? (
                          <UseTooltip text="Убрать из избранного">
                            <LuBookmark
                              size={24}
                              className="fill-primary hover:fill-none"
                              onClick={() =>
                                delete_favorite({
                                  id: course.id,
                                  type: "course",
                                })
                              }
                            />
                          </UseTooltip>
                        ) : (
                          <UseTooltip text="Добавить в избранное">
                            <LuBookmark
                              size={24}
                              className=" hover:fill-primary "
                              onClick={() =>
                                make_favorite({ course: course.id })
                              }
                            />
                          </UseTooltip>
                        )}
                      </HoverScale>
                    </div>

                    <div className="flex justify-between">
                      <div className="flex gap-2 items-center">
                        <span className="text-lg font-semibold flex gap-2 items-center ">
                          {course.discipline_name}
                          {course.is_end && (
                            <UseTooltip
                              text={`Сдано на ${course.course_points}`}
                            >
                              <LuBookCheck className="text-green-500 dark:text-green-400" />
                            </UseTooltip>
                          )}
                        </span>
                        <CourseStatisticTooltip
                          progress={course.progress}
                          count_lb_pr={course.count_lb_pr}
                          count_stud={course.count_stud}
                        />
                      </div>
                    </div>

                    <p className="mt-1 text-foreground/80 text-[15px]">
                      Количество часов : {course.count_hours}
                    </p>
                    <p className="mt-1 text-foreground/80 text-[15px]">
                      Кредитов : {course.credit}
                    </p>
                    <p className="mt-1 text-foreground/80 text-[15px]">
                      Форма контроля : {course.control_form}
                    </p>
                    {course.progress && (
                      <CategoryBar
                        values={[74, 13, 14]}
                        marker={{
                          value: course.course_points,
                          tooltip: `${course.course_points}`,
                          showAnimation: true,
                        }}
                        colors={["red", "amber", "lime"]}
                        className="pt-4"
                        showLabels={false}
                      />
                    )}
                  </div>
                  <div className="mt-4 flex items-center justify-between align-middle">
                    <Button
                      variant={"ghost"}
                      className="flex items-center gap-2 "
                      onClick={() =>
                        navigate(
                          "/" +
                            AppRoutes.PROFILE +
                            "/" +
                            course.course_owner[0].user_id
                        )
                      }
                    >
                      <Avatar>
                        <AvatarImage src={course.course_owner[0].avatar} />
                      </Avatar>

                      <span className="text-muted-foreground font-semibold flex flex-col text-md py-2">
                        {course.course_owner[0].owner_name}
                        <span className="font-medium text-xs text-muted-foreground">
                          Преподаватель
                        </span>
                      </span>
                    </Button>

                    <Button
                      className="shadow-none"
                      variant={"outline"}
                      onClick={() =>
                        navigate(AppSubRoutes.COURSE_THEMES + "/" + course.id)
                      }
                    >
                      Подробнее <ChevronRight />
                    </Button>
                  </div>
                </div>
              ))}
            </FadeInList>
          )}
          {data && !isStudent && (
            <FadeIn className="flex border rounded-xl py-4 px-5 min-w-1/3 justify-center items-center min-h-52">
              <HoverLift>
                <UseTooltip text="Создать новый курс">
                  <button onClick={() => openForm(FormQuery.ADD_COURSE)}>
                    <LuPlus size={28} className="text-muted-foreground w-24" />
                  </button>
                </UseTooltip>
              </HoverLift>
            </FadeIn>
          )}
        </div>
      </div>
    </div>
  );
};

export default CourseList;
