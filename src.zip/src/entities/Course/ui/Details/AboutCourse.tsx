import React from "react";
import TextBlock from "shared/components/TextBox";
import { Avatar, AvatarImage } from "shared/shadcn/ui/avatar";
import { Button } from "shared/shadcn/ui/button";
import { Card, CardContent, CardHeader } from "shared/shadcn/ui/card";
import { Separator } from "shared/shadcn/ui/separator";

const mockData = [
  {
    content: [
      {
        heading: "Goal",
        sub_heading: "правило1",
        text: "It is your job to predict if a passenger survived the sinking of the Titanic or not.",
      },
      {
        heading: "Metric",
        sub_heading: "правило1",

        text: "Your score is the percentage of passengers you correctly predict. This is known as accuracy.",
      },
      {
        heading: "Submission File Format",
        sub_heading: "правило1",

        text: "You should submit a csv file with exactly 418 entries plus a header row. It must have two columns: PassengerId and Survived.",
      },
    ],
  },
];

const AboutCourse = () => {
  return (
    <div className="flex p-2">
      <div className="pr-8 w-full flex flex-col gap-2">
        <div className="flex flex-col">
          <h1 className="text-2xl font-semibold tracking-tight mb-4">
            Основная информация
          </h1>
          <p className="text-md ">Количество часов: 12</p>
          <p className="text-md ">Кредитов: 13</p>
          <p className="text-md ">Форма контроля: Экзамен</p>
        </div>
        <div className="flex flex-col ">
          <h1 className="text-2xl font-semibold tracking-tight pt-1 mb-4">
            Участники
          </h1>

          <p className="text-md ">800 Участников</p>
          <p className="text-md ">325 Закончивших</p>
          <p className="text-md ">8 Групп</p>
          <p className="text-md ">160 файлов</p>
        </div>
        <div className="flex flex-col">
          <h1 className="text-2xl font-semibold tracking-tight pt-1 mb-4">
            Призы и номинации
          </h1>

          <p className="text-md ">Нет наград и номинаций</p>
        </div>
      </div>
    </div>
  );
};

export default AboutCourse;
