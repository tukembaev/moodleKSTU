import { CourseOverallFilesStatistic } from "./CourseOverallFilesStatistic";
import { CourseRegisterLineStatistic } from "./CourseRegisterLineStatistic";
import { CourseStudentsStatistic } from "./CourseStudentsStatistic";

const CourseStatistic = () => {
  return (
    <div className="flex gap-8 pt-4">
      <div className="flex-1 min-w-[300px] max-w-[400px]">
        <CourseStudentsStatistic />
      </div>
      <div className="flex-1 min-w-[300px] max-w-[400px]">
        <CourseRegisterLineStatistic />
      </div>
      <CourseOverallFilesStatistic />
    </div>
  );
};

export default CourseStatistic;
