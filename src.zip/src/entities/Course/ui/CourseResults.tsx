const CourseResults = () => {
  return <div>CourseResults</div>;
};

export default CourseResults;
