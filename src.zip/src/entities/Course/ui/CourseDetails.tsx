import { LuBookA, LuChartBar, LuInfo, LuSpeech } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import { TestimonialSection, UseTabs } from "shared/components";
import { CourseThemes } from "../model/types/course";
import AboutCourse from "./Details/AboutCourse";
import CourseResultTable from "./Details/CourseResultTable";
import CourseStatistic from "./Details/CourseStatistic";

const CourseDetails = ({ data }: { data: CourseThemes | undefined }) => {
  const navigate = useNavigate();
  const tabs = [
    {
      name: "О курсе",
      value: "about_course",
      content: <AboutCourse />,
      icon: <LuInfo />,
    },
    {
      name: "Успеваемость/Моя успеваемость",
      value: "students_progress",
      content: <CourseResultTable max_point={22} />,
      icon: <LuBookA />,
    },
    {
      name: "Графики",
      value: "charts",
      content: <CourseStatistic />,
      icon: <LuChartBar />,
    },
    {
      name: "Отзывы",
      value: "rules",
      content: <TestimonialSection />,
      icon: <LuSpeech />,
    },
  ];
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-col">
        <span className="text-4xl sm:text-5xl font-bold tracking-tight">
          {data?.discipline_name}
        </span>
        <p className="mt-1.5 text-lg text-muted-foreground w-2/4">
          {" "}
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error optio,
          perferendis provident laudantium magnam numquam aut harum consequatur.
          Obcaecati necessitatibus maiores dolor veniam tempora impedit error
          commodi sapiente sit aut.
        </p>
      </div>
      <UseTabs tabs={tabs}></UseTabs>
    </div>
  );
};

export default CourseDetails;
