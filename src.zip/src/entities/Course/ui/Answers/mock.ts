export const test = [
    {
        "id": "98625d61-9b45-41b3-9536-20115a80596d",
        "task": "2a0c25de-60ca-48b1-ac41-5722e66a84c3",
        "fullname": "Нурбеков Бексултан",
        "avatar": "https://utask.kstu.kg/media/avatars/photo_2024-07-17_12-59-25.jpg",
        "group": "ПИ-1-23",
        "status": false,
        "points": 0,
        "files": [
            {
                "id": "bd229991-1223-4617-9292-68090a4e09ac",
                "file": "https://utask.kstu.kg/education/education/media/files/login_h3DuYfj.svg",
                "file_names": "login_h3DuYfj.svg"
            }
        ]
    },
    {
        "id": "98625d61-9b45-41b3-9536-20115a80596asd",
        "task": "2a0c25de-60ca-48b1-ac41-5722e66a8as4c3",
        "fullname": "Ариф Тукембаев",
        "avatar": "https://sun9-2.userapi.com/s/v1/ig2/y4b39xn_d_Q82XcN6ilPYvORtWCHSu21SwMFpaofoE8OhzgZlf83LsHBRWx3CW9-qyva0HQrcZL-iRMu8p8O_vt6.jpg?quality=95&blur=50,20&as=32x32,48x47,72x71,108x106,160x158,240x237,360x355,480x473,540x532,640x631,720x710,828x816&from=bu&u=DOzj462BHe7hXrbJ5dfmvfKcnce6eO8Gs4HUS7bHDx8&cs=807x795",
        "group": "ПИ-2-18",
        "status": false,
        "points": 0,
        "files": [
            {
                "id": "bd229991-1223-4617-9292-68090a4e09ac",
                "file": "https://utask.kstu.kg/education/education/media/files/login_h3DuYfj.svg",
                "file_names": "login_h3DuYfj.svg"
            }
        ]
    }
]