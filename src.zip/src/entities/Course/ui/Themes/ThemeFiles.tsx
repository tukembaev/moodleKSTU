import { useQuery } from "@tanstack/react-query";
import { courseQueries } from "entities/Course/model/services/courseQueryFactory";
import { CourseMaterials } from "entities/Course/model/types/course";
import { useState } from "react";
import {
  LuClipboardList,
  LuEye,
  LuFolderDown,
  LuGlasses,
  LuList,
  LuMessageSquareText,
  LuTrash2,
} from "react-icons/lu";
import { HoverLift, UseTabs, UseTooltip } from "shared/components";
import PdfViewer from "shared/components/PdfPreview";
import { FormQuery } from "shared/config";
import { useAuth, useForm } from "shared/hooks";
import { Badge } from "shared/shadcn/ui/badge";
import { Button } from "shared/shadcn/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "shared/shadcn/ui/dialog";
import { Skeleton } from "shared/shadcn/ui/skeleton";

import ThemeAnswers from "../Answers/ThemeAnswers";

import { StudentComments } from "features/Course/hooks/StudentComments";
import ThemeFAQ from "./ThemeFAQ";
import { ThemeFeed } from "./ThemeFeed";

const ThemeFiles = ({ id, isOwner }: { id: string; isOwner: boolean }) => {
  const { data, isLoading, error } = useQuery(
    courseQueries.allTaskMaterials(id)
  );
  const { data: comments, isLoading: isLoadingComments } = useQuery(
    courseQueries.allThemeFeed(id)
  );

  const auth_data = useAuth();
  const openForm = useForm();

  const [preview, setPreview] = useState<CourseMaterials | null>(null);

  const handleOpenPreview = (material: CourseMaterials) => {
    if (preview?.id === material.id) {
      setPreview(null);
    } else {
      setPreview(material);
    }
  };

  const tabs = [
    {
      name: auth_data.isStudent ? "Мои файлы" : "Список студентов",
      value: "theme_answers",
      content: <ThemeAnswers id={id} />,
      icon: <LuList />,
    },
    {
      name: "Обсуждение",
      value: "feed",
      content: (
        <ThemeFeed
          items={comments || []}
          isLoading={isLoadingComments}
          theme_id={id}
        />
      ),
      icon: <LuMessageSquareText />,
    },
    {
      name: "FAQ",
      value: "faq",
      content: <ThemeFAQ theme_id={id} />,
      icon: <LuGlasses />,
    },
    ...(auth_data.isStudent
      ? [
        {
          name: "Замечания",
          value: "comments",
          content: <StudentComments theme_id={id} />,
          icon: <LuClipboardList />,
        },
      ]
      : []),
  ];

  // Объединяем материалы с файлами и URL в один массив
  const allMaterials = [
    ...(data?.filter((material) => material.files) || []),
    ...(data?.filter((material) => material.url) || []),
  ];

  const { mutate: delete_material } = courseQueries.delete_material();

  if (error) {
    return <p>Ошибка: {error.message}</p>;
  }

  const getFileIcon = (material: CourseMaterials) => {
    if (material.url) {
      return <LuGlasses className="size-8" />;
    }
    if (material.file?.includes(".pdf")) {
      return <LuEye className="size-8" />;
    }
    return <LuFolderDown className="size-8" />;
  };

  const getTooltipContent = (material: CourseMaterials) => {
    return (
      <div className="flex flex-col gap-1 max-w-[250px]">
        <p className="font-semibold">{material.url ? material.url_name : material.file_name || "Без названия"}</p>
        {material.description && <p className="text-xs text-muted-foreground">{material.description}</p>}
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-3 pt-6">
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <p className="text-lg font-semibold">Учебный материалы</p>
          {!auth_data.isStudent && (
            <Button
              variant="outline"
              className="cursor-pointer"
              onClick={() => openForm(FormQuery.ADD_MATERIAL, { id })}
            >
              Добавить материал
            </Button>
          )}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
            {Array.from({ length: 8 }).map((_, index) => (
              <Skeleton key={index} className="h-24 w-full rounded-lg" />
            ))}
          </div>
        ) : !allMaterials.length ? (
          <div className="rounded-md border p-8 text-center text-muted-foreground">
            Учебный материал пуст
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
            {allMaterials.map((material) => (
              <UseTooltip key={material.id} text={getTooltipContent(material)}>
                <div className="relative group">
                  <HoverLift>
                    <div className="flex flex-col items-center justify-center gap-2 p-4 rounded-lg border bg-card hover:bg-accent transition-colors cursor-pointer h-24">
                      {material.url ? (
                        <a
                          href={material.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex flex-col items-center justify-center gap-2 w-full h-full"
                        >
                          {getFileIcon(material)}
                        </a>
                      ) : material.file?.includes(".pdf") ? (
                        <Dialog
                          onOpenChange={(isOpen) => {
                            if (!isOpen) {
                              setPreview(null);
                            }
                          }}
                          open={preview?.id === material.id}
                        >
                          <DialogTrigger asChild>
                            <button
                              className="flex flex-col items-center justify-center gap-2 w-full h-full"
                              onClick={() => handleOpenPreview(material)}
                            >
                              {getFileIcon(material)}
                            </button>
                          </DialogTrigger>
                          <DialogContent className="max-w-screen-2xl w-[90vw] max-h-[90vh] overflow-hidden p-0">
                            <DialogHeader className="px-6 pt-6 pb-0">
                              <DialogTitle>{material.file_name || "Документ PDF"}</DialogTitle>
                            </DialogHeader>
                            <PdfViewer url={material.file || ""} inDialog={true} />
                          </DialogContent>
                        </Dialog>
                      ) : (
                        <a
                          href={material.file}
                          download={material.file_name}
                          className="flex flex-col items-center justify-center gap-2 w-full h-full"
                        >
                          {getFileIcon(material)}
                        </a>
                      )}
                    </div>
                  </HoverLift>
                  {isOwner && (
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute -top-2 -right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => delete_material(material.id)}
                    >
                      <LuTrash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </UseTooltip>
            ))}
          </div>
        )}
      </div>
      {/* <ThemeQuiz course_id={course_id} course_name={course_name} theme_id={id}/> */}
      <UseTabs tabs={tabs} />
    </div>
  );
};

export default ThemeFiles;
