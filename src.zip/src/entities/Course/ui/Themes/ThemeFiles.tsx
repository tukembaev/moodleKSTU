import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import {
  LuEye,
  LuEyeClosed,
  LuFolderDown,
  LuGlasses,
  LuList,
  LuMessageSquareText,
} from "react-icons/lu";
import { Modal, UseTabs } from "shared/components";
import { useAuth, useForm } from "shared/hooks";
import { Button } from "shared/shadcn/ui/button";
import { Dialog, DialogTrigger } from "shared/shadcn/ui/dialog";
import { Skeleton } from "shared/shadcn/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "shared/shadcn/ui/table";

import { FormQuery } from "shared/config";
import { Feed } from "entities/ez1";
import { mockData } from "shared/mocks/feedMock";
import { courseQueries } from "entities/Course/model/services/courseQueryFactory";
import { CourseMaterials } from "entities/Course/model/types/course";
import ThemeAnswers from "../Answers/ThemeAnswers";
import ThemeFAQ from "./ThemeFAQ";

const ThemeFiles = ({ id }: { id: string }) => {
  const { data, isLoading, error } = useQuery(
    courseQueries.allTaskMaterials(id)
  );
  const auth_data = useAuth();
  const openForm = useForm();

  const [preview, setPreview] = useState<CourseMaterials | null>(null);

  const handleOpenPreview = (material: CourseMaterials) => {
    if (preview?.id === material.id) {
      setPreview(null);
    } else {
      setPreview(material);
    }
  };
  const tabs = [
    {
      name: auth_data.isStudent ? "Мои файлы" : "Список студентов",
      value: "theme_answers",
      content: <ThemeAnswers id={id} />,
      icon: <LuList />,
    },
    {
      name: "Обсуждение",
      value: "feed",
      content: <Feed items={mockData} />,
      icon: <LuMessageSquareText />,
    },
    {
      name: "FAQ",
      value: "faq",
      content: <ThemeFAQ theme_id={id} />,
      icon: <LuGlasses />,
    },
  ];

  if (error) {
    return <p>Ошибка : {error.message}</p>;
  }
  return (
    <div className="flex flex-col gap-3 pt-6 ">
      <p>Учебный материал</p>
      <div className="rounded-md border">
        <Table>
          <TableHeader className="">
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-[300px] py-4">Название файла</TableHead>
              {!auth_data.isStudent && (
                <TableHead className="text-right">
                  <Button
                    variant="outline"
                    className="cursor-pointer"
                    onClick={() => openForm(FormQuery.ADD_MATERIAL, { id: id })}
                  >
                    Добавить материал
                  </Button>
                </TableHead>
              )}
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 2 }).map((_, index) => (
                <TableRow key={index}>
                  <TableCell>
                    <Skeleton className="h-4 w-[200px]" />
                  </TableCell>
                  <TableCell className="flex justify-end gap-3">
                    <Skeleton className="h-8 w-8 rounded" />
                    <Skeleton className="h-8 w-8 rounded" />
                  </TableCell>
                </TableRow>
              ))
            ) : !data?.length ? (
              <TableRow key={1}>
                <TableCell colSpan={4}>
                  Учебный материал пуст, добавьте прямо сейчас!
                </TableCell>
              </TableRow>
            ) : (
              data?.map((material) => (
                <TableRow key={material.id}>
                  <TableCell className="font-medium">
                    {material.file_name}
                  </TableCell>
                  <TableCell className="justify-end flex gap-3">
                    {material.file.includes(".pdf") && (
                      <Dialog
                        onOpenChange={(isOpen) => {
                          if (!isOpen) {
                            setPreview(null);
                          }
                        }}
                        open={preview?.id === material.id}
                      >
                        <DialogTrigger>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleOpenPreview(material)}
                          >
                            {preview?.id === material.id ? (
                              <LuEyeClosed />
                            ) : (
                              <LuEye />
                            )}
                          </Button>
                        </DialogTrigger>
                        <Modal data={material} />
                      </Dialog>
                    )}
                    <a
                      href={material.file}
                      download={material.files}
                      className="text-blue-500 hover:text-blue-700"
                    >
                      <Button variant="outline" size="icon">
                        <LuFolderDown />
                      </Button>
                    </a>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      <UseTabs tabs={tabs} />
    </div>
  );
};

export default ThemeFiles;
