import React from "react";

const ThemeDiscussion = () => {
  return <div>ThemeDiscussion</div>;
};

export default ThemeDiscussion;
