import { useQuery } from "@tanstack/react-query";
import { courseQueries } from "entities/Course/model/services/courseQueryFactory";
import { useNavigate, useParams } from "react-router-dom";
import { FadeInList } from "shared/components";
import { FormQuery } from "shared/config";
import { useAuth, useForm } from "shared/hooks";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "shared/shadcn/ui/accordion";
import { Skeleton } from "shared/shadcn/ui/skeleton";

const faq = [
  {
    question: "What is your return policy?",
    answer:
      "You can return unused items in their original packaging within 30 days for a refund or exchange. Contact support for assistance.",
  },
  {
    question: "How do I track my order?",
    answer:
      "Track your order using the link provided in your confirmation email, or log into your account to view tracking details.",
  },
  {
    question: "Do you ship internationally?",
    answer:
      "Yes, we ship worldwide. Shipping fees and delivery times vary by location, and customs duties may apply for some countries.",
  },
  {
    question: "What payment methods do you accept?",
    answer:
      "We accept Visa, MasterCard, American Express, PayPal, Apple Pay, and Google Pay, ensuring secure payment options for all customers.",
  },
  {
    question: "What if I receive a damaged item?",
    answer:
      "Please contact our support team within 48 hours of delivery with photos of the damaged item. We’ll arrange a replacement or refund.",
  },
];

const ThemeFAQ = ({ theme_id }: { theme_id: string }) => {
  const { id } = useParams();
  const { isStudent } = useAuth();
  const openForm = useForm();

  const { data, isLoading } = useQuery(courseQueries.allThemeFAQ(id || ""));

  return (
    <>
      {isLoading ? (
        <FadeInList>
          {Array.from({ length: 1 }).map((_, index) => (
            <div
              key={index}
              className="flex flex-col border rounded-xl py-6 px-5 justify-between transition-all duration-300 lg:col-span-1"
            >
              <div className="flex justify-between">
                <Skeleton className="w-82 h-5 rounded-md " />
                <Skeleton className="w-5 h-5 rounded-md " />
              </div>
            </div>
          ))}
        </FadeInList>
      ) : (
        <Accordion type="single" className="pl-2 ">
          {data?.map(({ question, answer }, index) => (
            <AccordionItem key={question} value={`question-${index}`}>
              <AccordionTrigger className="text-left text-lg cursor-pointer">
                {question}
              </AccordionTrigger>
              <AccordionContent>{answer}</AccordionContent>
            </AccordionItem>
          ))}
          {!isStudent && (
            <AccordionItem
              value=""
              onClick={() =>
                openForm(FormQuery.ADD_THEME_FAQ, {
                  id: theme_id || "",
                })
              }
              className="text-left text-lg pt-4 font-medium cursor-pointer"
            >
              Добавить новый FAQ
            </AccordionItem>
          )}
        </Accordion>
      )}
    </>
  );
};

export default ThemeFAQ;
