import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { courseQueries } from "../model/services/courseQueryFactory";
import ListOfThemes from "./Themes/ListOfThemes";

import { TestCard, testQueries } from "entities/Test";
import { LuShapes } from "react-icons/lu";
import { Separator } from "shared/shadcn/ui/separator";
import CourseThemeSkeleton from "../lib/skeletons/CourseThemeSkeleton";
import CourseDetails from "./CourseDetails";

const CourseThemes = () => {
  const { id } = useParams();

  const safeId = id || "default_id";

  const { data, isLoading, error } = useQuery(courseQueries.allTasks(safeId));
  const {
    data: course_tests,
    // isLoading: isLoadingTest,
    // error: errorTest,
  } = useQuery(testQueries.allTest(`?course=${safeId}`));

  if (isLoading) return <CourseThemeSkeleton />;
  if (error) return <div>Something went wrong {error.message}</div>;

  return (
    <div className="min-h-screen flex py-3">
      <div className="w-full flex flex-col gap-4">
        <CourseDetails data={data} />
        <Separator />
        <h2 className="text-3xl pl-2 italic font-normal flex gap-2 items-center">
          <LuShapes />
          Тесты
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {course_tests?.map((item) => (
            <TestCard key={item.id} {...item} />
          ))}
        </div>
        <Separator className="my-2" />
        {/* //IMPORTANT сказать бексу чтобы исправил когда студент отправляет несколько файлов, ошибка 500 */}
        {data && <ListOfThemes data={data} />}
      </div>
    </div>
  );
};

export default CourseThemes;
