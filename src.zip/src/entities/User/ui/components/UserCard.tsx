import UserCardSkeleton from "entities/User/lib/UserCardSkeleton";
import { UserProfileData } from "entities/User/types/user";
import { MapPin, User } from "lucide-react";
import { useState } from "react";
import { LuPencil, LuPhone, LuSend } from "react-icons/lu";
import { useAuth } from "shared/hooks";

import { Avatar, AvatarFallback, AvatarImage } from "shared/shadcn/ui/avatar";
import { Card } from "shared/shadcn/ui/card";
import { UserCategoryRadarStatistic } from "./UserCategoryRadarStatistic";

const UserCard = ({
  data,
  isLoading,
}: {
  data: UserProfileData | undefined;
  isLoading: boolean;
}) => {
  const auth_data = useAuth();
  const [hovered, setHovered] = useState(false);

  const handleAvatarClick = () => {
    console.log("Изменение аватара");
  };

  if (isLoading) return <UserCardSkeleton />;
  return (
    <Card className="relative w-full p-6 rounded-4xl shadow-md flex flex-row justify-between">
      <div className="relative flex items-center gap-16 pl-20 py-6">
        {data?.user_id === auth_data?.id ? (
          <div
            className="relative w-64 h-64 cursor-pointer"
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            onClick={handleAvatarClick}
          >
            <Avatar className="w-64 h-64 border-4 border-white shadow-md">
              <AvatarImage src={data?.avatar} alt="User avatar" />
              <AvatarFallback>M</AvatarFallback>
            </Avatar>
            {hovered && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
                <LuPencil size={40} className="text-white" />
              </div>
            )}
          </div>
        ) : (
          <Avatar className="w-64 h-64 border-4 border-white shadow-md">
            <AvatarImage src={data?.avatar} alt="User avatar" />
            <AvatarFallback>M</AvatarFallback>
          </Avatar>
        )}

        <div>
          <span className="text-sm font-bold text-gray-500">{data?.group}</span>
          <h2 className="text-4xl font-bold">
            {data?.first_name} {data?.last_name}
          </h2>
          <p className="text-gray-500">{data?.position}</p>
          <div className="mt-2 text-sm  space-y-3">
            <div className="flex items-center gap-2">
              <User size={20} /> <span>{data?.bio}</span>
            </div>
            <div className="flex items-center gap-2">
              <LuPhone size={20} />
              <a href={`tel:${data?.number_phone}`} className="hover:underline">
                {data?.number_phone}
              </a>
            </div>

            <div className="flex items-center gap-2">
              <MapPin size={20} />
              <a href={`mailto:${data?.email}`} className="hover:underline">
                {data?.email}
              </a>
            </div>

            <div className="flex items-center gap-2">
              <LuSend size={20} />
              <a
                href={`https://t.me/${data?.telegram_username?.replace(
                  "@",
                  ""
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline"
              >
                {data?.telegram_username}
              </a>
            </div>
          </div>
        </div>
      </div>
      <UserCategoryRadarStatistic />
    </Card>
  );
};

export default UserCard;
