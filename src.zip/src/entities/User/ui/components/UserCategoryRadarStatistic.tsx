"use client";

import { PolarAngleAxis, PolarGrid, Radar, RadarChart } from "recharts";

import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "shared/shadcn/ui/chart";

const chartData = [
  { category: "Технологии", points: 186, max_points: 248 },
  { category: "Бизнес", points: 0, max_points: 0 },
  { category: "Финансы", points: 50, max_points: 100 },
  { category: "Здоровье", points: 0, max_points: 0 },
  { category: "Политика", points: 10, max_points: 40 },
  { category: "Наука", points: 31, max_points: 70 },
  { category: "Спорт", points: 0, max_points: 0 },
];

const chartConfig = {
  points: {
    label: "Очки",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig;

export function UserCategoryRadarStatistic() {
  return (
    <div className="w-full max-w-sm aspect-square">
      <ChartContainer config={chartConfig} className="w-full h-[80%] mt-12">
        <RadarChart
          data={chartData}
          outerRadius="80%"
          margin={{ top: 10, right: 10, bottom: 10, left: 10 }}
        >
          <ChartTooltip
            cursor={false}
            content={<ChartTooltipContent indicator="line" />}
          />
          <PolarAngleAxis
            dataKey="category"
            tick={({ x, y, textAnchor, index }) => {
              const { points, max_points, category } = chartData[index];
              return (
                <text
                  x={x}
                  y={index === 0 ? y - 10 : y}
                  textAnchor={textAnchor}
                  fontSize={13}
                  fontWeight={500}
                >
                  <tspan>
                    {points}/{max_points}
                  </tspan>
                  <tspan
                    x={x}
                    dy={"1rem"}
                    fontSize={12}
                    className="fill-muted-foreground"
                  >
                    {category}
                  </tspan>
                </text>
              );
            }}
          />
          <PolarGrid />

          <Radar
            dataKey="points"
            stroke="hsl(221.2 83.2% 53.3%)"
            fill="hsl(221.2 83.2% 53.3%)"
            fillOpacity={0.6}
          />
        </RadarChart>
      </ChartContainer>
    </div>
  );
}
