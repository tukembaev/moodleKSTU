import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "shared/shadcn/ui/card";
import brilliants from "/src/assets/diamond.svg";
import emerald from "/src/assets/emerald.svg";
import iron from "/src/assets/iron.svg";

const courses = [
  {
    title: "Методы оптимизации",
    excelent: 4,
    good: 4,
    bad: 4,

    date_completed: "12 апреля 2025",
  },
];
const UserCompletedCourses = () => {
  return (
    <div>
      <h2 className="text-3xl font-bold tracking-tight italic pb-8">
        Завершенные курсы
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {courses.map((item) => (
          <Card className="min-h-68 flex flex-col justify-between">
            <div>
              <CardHeader className="text-lg font-semibold w-full break-all">
                {item.title}
              </CardHeader>
              <CardContent className="flex flex-col gap-2 pt-4">
                <p className="font-medium text-gray-500">Медали</p>
                <div className="flex gap-4">
                  <div className="flex gap-1">
                    <img src={brilliants} className="w-5" alt="" />
                    <span>{item.excelent}</span>
                  </div>
                  <div className="flex gap-1">
                    <img src={emerald} className="w-5" alt="" />
                    <span>{item.good}</span>
                  </div>
                  <div className="flex gap-1">
                    <img src={iron} className="w-5" alt="" />
                    <span>{item.bad}</span>
                  </div>
                </div>
              </CardContent>
            </div>

            <CardFooter className="">{item.date_completed}</CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default UserCompletedCourses;
