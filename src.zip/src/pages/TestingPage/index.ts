import TestingPage from "./ui/TestingPage";

export {TestingPage}