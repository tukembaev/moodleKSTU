import { useQuery } from "@tanstack/react-query";
import { FavoriteCourses, FavoriteThemes } from "entities/Course";

import { userQueries } from "entities/User";
import { useState } from "react";
import { LuComponent, LuLayoutGrid } from "react-icons/lu";
import { UseTabs } from "shared/components";

import { useAuth } from "shared/hooks";

import { Separator } from "shared/shadcn/ui/separator";
import { Cat, Dog, Fish, Rabbit, Turtle } from "lucide-react";

const MainPage = () => {
  const auth_data = useAuth();
  const {
    data: favorites,
    isLoading,
    error,
  } = useQuery(userQueries.user_favorites());

  if (error) return <p>{error.message}</p>;

  return (
    <div className="px-6 py-4">
      <div className="flex flex-col">
        <h2 className="text-2xl sm:text-2xl font-semibold tracking-tight text-left">
          Добро пожаловать,
          <br />
          <span className="text-4xl sm:text-4xl font-semibold tracking-tight text-left">
            {auth_data.first_name} {auth_data.surname}
          </span>
        </h2>
        <p className="mt-1.5 text-md text-muted-foreground">
          Продолжи с того места, где остановился, или начни что-то новое!
        </p>
      </div>
      <Separator className="my-6" />
      <h2 className="text-4xl sm:text-4xl font-semibold tracking-tight text-left italic ">
        Избранное
      </h2>

      {favorites?.courses.length || favorites?.themes.length ? (
        <div>
          <UseTabs
            classNames="mt-4"
            tabs={[
              {
                name: "Курсы",
                value: "courses",
                content: (
                  <FavoriteCourses
                    isLoading={isLoading}
                    data={favorites?.courses || []}
                  />
                ),
                count: favorites?.courses?.length || 0,
                icon: <LuLayoutGrid />,
              },
              {
                name: "Темы",
                value: "themes",
                content: (
                  <FavoriteThemes
                    isLoading={isLoading}
                    data={favorites?.themes || []}
                  />
                ),
                count: favorites?.themes?.length || 0,
                icon: <LuComponent />,
              },
            ]}
          />
          <Separator className="my-6" />
        </div>
      ) : (
        "У вас нет избранных курсов или тем"
      )}
    </div>
  );
};

export default MainPage;
