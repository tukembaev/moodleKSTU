import { GroupPageAsync } from "./ui/GroupPage.async";

export {GroupPageAsync as GroupPage}