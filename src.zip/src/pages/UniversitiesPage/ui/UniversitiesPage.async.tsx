import { lazy } from "react";

export const UniversitiesPageAsync = lazy(() => import("./UniversitiesPage"));
