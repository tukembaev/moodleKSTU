export interface FavoritePayload {
    theme?:string;
    course?:string
  }