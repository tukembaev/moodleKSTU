import { useForm } from "react-hook-form";
import { LuCloudUpload, LuX } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import { Button } from "shared/shadcn/ui/button";
import { Card } from "shared/shadcn/ui/card";
import { Input } from "shared/shadcn/ui/input";
import { Label } from "shared/shadcn/ui/label";

import { testQueries } from "entities/Test/model/services/testQueryFactory";
import { useEffect, useState } from "react";
import { UseDatePicker } from "shared/components";

import { useQuery } from "@tanstack/react-query";
import { courseQueries } from "entities/Course/model/services/courseQueryFactory";
import { UseMultiSelect } from "shared/components/UseMultipleSelect";
import { TestPayload } from "../model/types/test_payload";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "shared/shadcn/ui/popover";
import { cn } from "shared/lib/utils";
import { CalendarIcon } from "lucide-react";
import { Calendar } from "shared/shadcn/ui/calendar";
import { format } from "date-fns";

const Add_Test = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    control,
  } = useForm<TestPayload>();
  const { data, isLoading, error } = useQuery(courseQueries.allCourses());

  const { mutate: add_test, isPending } = testQueries.create_test();

  const [selected, setSelected] = useState<string[]>([]);

  const [date, setDate] = useState<Date | undefined>(new Date());

  useEffect(() => {
    setValue("deadline", date!);
  }, [date]);

  const courseOptions = data?.map((course: any) => ({
    label: course.discipline_name,
    value: String(course.id), // строкой, т.к. селект работает со строками
  }));
  useEffect(() => {
    setValue(
      "course",
      selected.map((id) => id) // 👈 сохраняем как число
    );
  }, [selected]);

  const navigate = useNavigate();

  const onSubmit = async (data: TestPayload) => {
    add_test(data);
  };
  // https://docs.google.com/forms/d/e/1FAIpQLSdYBbyB6kWiHNlB_Ng9qDMPHZg_4jvE60a78lpUoAfTfRVx2Q/viewform?usp=dialog

  // https://docs.google.com/spreadsheets/d/1COC5m2Ftp-xIPeXZKoeZs2WDuuKBPTUGdjsw8qkvh54/edit?resourcekey=&gid=114923027#gid=114923027

  console.log(selected);
  return (
    <section className="py-4">
      <Card className="flex flex-col gap-4 p-6">
        <form onSubmit={handleSubmit(onSubmit)} className="grid gap-4">
          <div className="flex flex-col gap-2">
            <Label>Название теста</Label>
            <Input
              type="text"
              placeholder="Введите название"
              {...register("title", { required: true })}
            />
            {errors.title && (
              <span className="text-xs text-red-500">Название обязательно</span>
            )}
          </div>

          <div className="flex flex-col gap-2">
            <Label>Описание</Label>
            <Input
              type="text"
              placeholder="Введите описание"
              {...register("description", { required: true })}
            />
            {errors.description && (
              <span className="text-xs text-red-500">Описание обязательно</span>
            )}
          </div>

          <div className="flex flex-col gap-2 w-full">
            <Label htmlFor="deadline">Дедлайн</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[280px] justify-start text-left font-normal",
                    !date && "text-muted-foreground"
                  )}
                  isAnimated={false}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : <span>Выбери дату</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 z-[9999]">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            {errors.deadline && (
              <span className="text-xs text-red-500">Дедлайн обязателен</span>
            )}
          </div>
          <div className="flex flex-col gap-2 w-full">
            <Label htmlFor="deadline">
              Выберите курсы для закрепления теста
            </Label>
            <UseMultiSelect
              options={courseOptions || []}
              value={selected}
              onChange={setSelected}
              placeholder="Выбери фреймворки"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>Максимальное количество баллов</Label>
            <Input
              type="number"
              placeholder="Введите число"
              {...register("max_points", { required: true, min: 0 })}
            />
            {errors.max_points && (
              <span className="text-xs text-red-500">
                Укажите корректное число
              </span>
            )}
          </div>

          <div className="flex flex-col gap-2">
            <Label>Ссылка на форму</Label>
            <Input
              type="url"
              placeholder="https://example.com/form"
              {...register("link_form", { required: true })}
            />
            {errors.link_form && (
              <span className="text-xs text-red-500">Ссылка обязательна</span>
            )}
          </div>

          <div className="flex flex-col gap-2">
            <Label>Ссылка на документ</Label>
            <Input
              type="url"
              placeholder="https://example.com/doc"
              {...register("link_doc", { required: true })}
            />
            {errors.link_doc && (
              <span className="text-xs text-red-500">Ссылка обязательна</span>
            )}
          </div>

          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button
              variant="outline"
              className="w-full mt-4"
              disabled={isPending}
              onClick={(e) => {
                e.preventDefault();
                navigate(-1);
              }}
            >
              <LuX /> Отменить
            </Button>
            <Button type="submit" className="w-full mt-4" disabled={isPending}>
              <LuCloudUpload />{" "}
              {isPending ? "Загрузка..." : "Опубликовать тест"}
            </Button>
          </div>
        </form>
      </Card>
    </section>
  );
};

export default Add_Test;
