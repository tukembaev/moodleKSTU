import { jwtDecode } from "jwt-decode";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { LuDoorOpen, LuMail } from "react-icons/lu";
import { useNavigate } from "react-router-dom";
import { useAuth } from "shared/hooks";
import { Button } from "shared/shadcn/ui/button";
import { Input } from "shared/shadcn/ui/input";
import { authUser } from "../model/services/loginAPI";
import { DecodedJWT, LoginPayload } from "../model/types/login";

interface SignupProps {
  heading?: string;
  subheading?: string;
  logo?: {
    url: string;
    src: string;
    alt: string;
  };
  signupText?: string;
  googleText?: string;
  loginText?: string;
  loginUrl?: string;
}

const LoginForm = ({
  heading = "OnlineKSTU",
  subheading = "Введите ваши данные",
  logo = {
    url: "https://www.shadcnblocks.com",
    src: "https://cdn-icons-png.freepik.com/256/11999/11999402.png?semt=ais_hybrid",
    alt: "kstuLogo",
  },
  googleText = "Корпоративная почта",
}: SignupProps) => {
  const {
    register,
    handleSubmit,
    // watch,
    formState: { errors },
  } = useForm<LoginPayload>();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const onSubmit = handleSubmit(async (data) => {
    setLoading(true);
    let response = await authUser(data);
    debugger;
    if (response) {
      const decoded = jwtDecode<DecodedJWT>(response.access);
      const { first_name, surname, imeag, user, position } = decoded.user_data;
      debugger;
      localStorage.setItem(
        "auth_data",
        JSON.stringify({
          ...response,
          id: user,
          first_name,
          surname,
          imeag,
          position,
          isStudent: position === null,
        })
      );
      window.dispatchEvent(new Event("storage"));
      setLoading(false);
      //BUG временное решение для борьбы с рефреш токеном
      window.location.href = "/main";
    }
  });
  const onExit = () => {
    localStorage.removeItem("auth_data");
    window.dispatchEvent(new Event("storage"));
  };
  // const formData = watch();
  const auth_data = useAuth();

  return (
    <section className="py-4">
      <div className="container">
        <div className="flex flex-col gap-4">
          <div className="mx-auto w-full max-w-sm rounded-md p-6 shadow">
            <div className="mb-6 flex flex-col">
              <a href={logo.url}>
                <img
                  src={logo.src}
                  alt={logo.alt}
                  className="mb-7 h-26 w-auto mx-auto"
                />
              </a>
              <p className="mb-2 text-2xl font-bold">{heading}</p>
              {auth_data ? (
                ""
              ) : (
                <p className="text-muted-foreground">{subheading}</p>
              )}
            </div>
            {auth_data ? (
              <div className="flex flex-col justify-center gap-2 items-center">
                <img
                  className="h-18 w-18 rounded-full "
                  src={auth_data.imeag}
                  alt=""
                />
                <h1>{`${auth_data.first_name} ${auth_data.surname}`}</h1>
                <h2 className="text-xs leading-none">{auth_data.position}</h2>
                <Button
                  variant="default"
                  type="submit"
                  className="w-full mt-4 mb-2"
                  onClick={() => navigate("/main")}
                >
                  Войти
                </Button>
                <Button variant="outline" className="w-full" onClick={onExit}>
                  <LuDoorOpen className="mr-2 size-5" />
                  Выйти из аккаунта
                </Button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="grid gap-2">
                <label>ИНН</label>
                <Input
                  type="text"
                  placeholder="Введите ИНН"
                  {...register("username", { required: true })}
                />
                {errors.username && (
                  <span className="text-red-500">First name is required</span>
                )}
                <label>Пароль</label>
                <Input
                  type="text"
                  placeholder="Введите пароль"
                  {...register("password", { required: true })}
                />
                {errors.password && (
                  <span className="text-red-500">Last name is required</span>
                )}
                {loading ? (
                  <div className="w-full mt-4 mb-2">Loading...</div>
                ) : (
                  <Button
                    variant="default"
                    type="submit"
                    className="w-full mt-4 mb-2"
                  >
                    Войти
                  </Button>
                )}

                <Button variant="outline" className="w-full">
                  <LuMail className="mr-2 size-5" />
                  {googleText}
                </Button>

                <div className="mx-auto mt-8 flex justify-center gap-1 text-sm text-muted-foreground text-center">
                  <p>
                    Ваш пароль по умолчанию ваш ИНН если вы сотрудник.Если вы
                    студент s + ИНН.
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoginForm;
