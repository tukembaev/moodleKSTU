import $api_base_edu from "shared/api/api_base_edu";
import { SearchBar } from "./search";
import { queryOptions } from "@tanstack/react-query";

const getGlobalSearchData = async (search:string):Promise<SearchBar> => {
    const response = await $api_base_edu.get(`v1/global-search?search=${search}`);
    return response.data;
  };

  export const searchQueries = {
      searchResults: (searchText: string | null) =>
        queryOptions({
          queryKey: ['search',searchText],
          queryFn: () => getGlobalSearchData(searchText as string),
          enabled: !!searchText,
        }),
  };
  