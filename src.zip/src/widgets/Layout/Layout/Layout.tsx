import { FC, ReactNode, memo } from "react";

import { SidebarProvider } from "shared/shadcn/ui/sidebar";
import Header from "./ui/Header/Header";
import Sidebar from "./ui/Sidebar/Sidebar";

import { useAuth } from "shared/hooks";
import { Toaster } from "shared/shadcn/ui/sonner";
import { GlobalDrawer } from "shared/components";

interface LayoutProps {
  children: ReactNode;
}
//TODO Продумать если гость будет заходить то скрывать ему sidebar и показывать только страницу с университетами и в роутинге сделать так чтобы при переходах через url выводило 404 и авторизуйтесь

const Layout: FC<LayoutProps> = ({ children }) => {
  const auth = useAuth();

  if (!auth) return <>{children}</>;
  return (
    <SidebarProvider
      defaultOpen={false}
      style={
        {
          "--sidebar-width": "14rem",
          "--sidebar-width-mobile": "14rem",
        } as React.CSSProperties
      }
    >
      <div className="flex flex-col min-h-screen w-full">
        <div className="flex flex-grow">
          <Sidebar />
          <div className="w-full">
            <Header />
            <div className="pt-4 px-4 overflow-hidden pb-18">{children}</div>
          </div>
        </div>
        {/* <Footer /> */}
        <Toaster richColors closeButton expand={false} className="z-80" />
        <GlobalDrawer />
      </div>
    </SidebarProvider>
  );
};

export default memo(Layout);
