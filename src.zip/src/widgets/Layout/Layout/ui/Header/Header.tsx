import { LuBell } from "react-icons/lu";
import { ModeToggle } from "shared/components/ModeToggle";
import { Button } from "shared/shadcn/ui/button";
import { Separator } from "shared/shadcn/ui/separator";
import { SidebarTrigger } from "shared/shadcn/ui/sidebar";
import { CommandSearchBar } from "widgets/CommandSearchBar";
import UserMenu from "widgets/UserMenu/ui/UserMenu";

const Header = () => {
  return (
    <header className="py-4 px-2 border-b w-full sticky top-0  z-30">
      <div className="flex justify-between items-center">
        <div className="flex gap-3 items-center relative">
          <SidebarTrigger className="cursor-pointer " />
          <Separator orientation="vertical" className="min-h-6" />
          <div className="max-h-[35px] flex pl-3">
            <CommandSearchBar />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative flex gap-2">
            <ModeToggle />

            <Button variant={"outline"} size="icon">
              <LuBell />
              <span className="absolute top-0 right-0 px-1 min-w-4 translate-x-1/2 -translate-y-1/2 origin-center flex items-center justify-center rounded-full text-xs bg-destructive text-destructive-foreground">
                2
              </span>
            </Button>
          </div>
          <UserMenu />
        </div>
        {/* <div className="flex gap-3 items-center pr-4">
          <Button variant="outline" size={"icon"}>
            <LuBell />
          </Button>
         
        </div> */}
      </div>
    </header>
  );
};

export default Header;
