import {
  Sidebar as ShadcnSidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "shared/shadcn/ui/sidebar";
import logo from "/src/assets/logo.svg";
import {
  ChartPie,
  ClipboardList,
  FolderInput,
  GraduationCap,
  University,
  Users,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import { AppRoutes, RoutePath } from "shared/config";
import { useAuth } from "shared/hooks";

const navigationItems: {
  title: string;
  url: (typeof RoutePath)[keyof typeof RoutePath];
  icon: React.ElementType;
}[] = [
  {
    title: "Главная",
    url: RoutePath.main,
    icon: ChartPie,
  },
  {
    title: "Курсы",
    url: AppRoutes.COURSES,
    icon: GraduationCap,
  },
  {
    title: "Регистрация",
    url: RoutePath.registration,
    icon: FolderInput,
  },
  {
    title: "Тестирование",
    url: RoutePath.test,
    icon: ClipboardList,
  },

  {
    title: "Группы",
    url: RoutePath.groups,
    icon: Users,
  },
  {
    title: "Университеты",
    url: RoutePath.universities,
    icon: University,
  },
];
const Sidebar = () => {
  const url = useLocation();
  const { isStudent } = useAuth();
  const { state } = useSidebar();

  // Фильтруем пункты навигации
  const filteredNavigationItems = navigationItems.filter(
    (item) =>
      (isStudent && item.url !== RoutePath.groups) ||
      (!isStudent && item.url !== RoutePath.registration)
  );

  return (
    <ShadcnSidebar collapsible="icon">
      <SidebarHeader className="border-b">
        {state === "expanded" ? (
          <img src={logo} alt="kstuLogo" className="h-26 w-auto mx-auto" />
        ) : (
          <img src={logo} alt="kstuLogo" className="h-8 w-auto mx-auto" />
        )}
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Application</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredNavigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={url.pathname.includes(item.url)}
                  >
                    <NavLink to={item.url}>
                      <item.icon />
                      <span>{item.title}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </ShadcnSidebar>
  );
};
export default Sidebar;
