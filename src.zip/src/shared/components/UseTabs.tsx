import React from "react";
import { LuCpu } from "react-icons/lu";
import { Badge } from "shared/shadcn/ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "shared/shadcn/ui/tabs";

interface UseTabsProps {
  tabs: {
    name: string;
    value: string;
    content: React.ReactNode;
    count?: number;
    icon: React.ReactNode;
  }[];
  classNames?: string;
}

export default function UseTabs({ tabs, classNames }: UseTabsProps) {
  return (
    <Tabs defaultValue={tabs[0].value} className={`w-full ${classNames}`}>
      <TabsList className="p-0 bg-background justify-start rounded-none gap-1">
        {tabs.map((tab) => (
          <TabsTrigger
            key={tab.value}
            value={tab.value}
            className="rounded-none bg-background h-full data-[state=active]:shadow-none border-b-2 border-transparent data-[state=active]:border-b-primary cursor-pointer"
          >
            <p className="text-[13px] flex gap-2 items-center">
              {tab.icon}
              {tab.name}
            </p>
            {!!tab.count && (
              <Badge
                variant="secondary"
                className="ml-2 px-1 py-0 text-xs rounded-full"
              >
                {tab.count}
              </Badge>
            )}
          </TabsTrigger>
        ))}
      </TabsList>
      {tabs.map((tab) => (
        <TabsContent key={tab.value} value={tab.value}>
          {tab.content}
        </TabsContent>
      ))}
    </Tabs>
  );
}
