import { CourseMaterials } from "entities/Course/model/types/course";
import React from "react";

import { LuFileQuestion } from "react-icons/lu";

import {
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "shared/shadcn/ui/dialog";

interface ModalProps {
  data: CourseMaterials;
}

const Modal: React.FC<ModalProps> = ({ data }) => {
  const extension = data.file?.split(".").pop()?.toLowerCase();

  // //IMPORTANT Сказать бексу что preview не работает потому что
  // chromewebdata/:1 Refused to display 'https://utask.kstu.kg/' in a frame because it set 'X-Frame-Options' to 'deny'.
  return (
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{data.file_name}</DialogTitle>
        {/* <p>{data.course_detail}</p> */}
      </DialogHeader>
      <div className="space-y-4">
        {(() => {
          if (["mp4", "mkv", "avi", "mov", "webm"].includes(extension || "")) {
            return (
              <video controls className="w-full">
                {" "}
                <source src={data.file} type={`video/${extension}`} /> ``{" "}
              </video>
            );
          }

          if (["pdf"].includes(extension || "")) {
            return (
              <embed
                src={data.file}
                type="application/pdf"
                className="w-full h-96"
              />
            );
          }

          if (["mp3", "wav", "flac", "aac", "ogg"].includes(extension || "")) {
            return (
              <audio controls className="w-full">
                {" "}
                <source src={data.file} type={`audio/${extension}`} />{" "}
              </audio>
            );
          }

          return (
            <div className="flex items-center gap-2">
              <LuFileQuestion />
              <a
                href={data.file}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-500 hover:underline"
              >
                {data.file}
              </a>
            </div>
          );
        })()}
      </div>
    </DialogContent>
  );
};

export default Modal;
