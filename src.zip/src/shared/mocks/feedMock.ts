
export type FeedItem = {
    id: string;
    user: {
      user_id:number,
      name: string;
      avatar: string;
    };
    content: string;
    timestamp: string;
    replies?: FeedItem[];
    likes?: number;
    onReply?: (id: string, message: string) => void;
    onLike?: (id: string) => void;
  };

export const mockData: FeedItem[] = [
    {
      id: "1",
      user: { user_id:47095 ,name: "Бекс Нурбеков", avatar: "https://diabetoved.ru/upload/resize_cache/iblock/fa0/940_387_1/7ldzs3rbp7w2ynlo85kgesarwqwa15fy.jpg" },
      content: "Отдел ОРПО самый лучший отдел в политехе епта",
      timestamp: "1 час назад",
      likes: 2,
      replies: [
        {
          id: "1-1",
          user: { user_id: 1 ,name: "Мади Сахарок", avatar: "https://diabetoved.ru/upload/resize_cache/iblock/fa0/940_387_1/7ldzs3rbp7w2ynlo85kgesarwqwa15fy.jpg" },
          content: "Согласен с тобой!",
          timestamp: "30 мин назад",
          likes: 1,
          replies: [
            {
              id: "1-2",
              user: { user_id: 28449, name: "Арслан Жумалиев", avatar: "https://mangabuff.ru/img/manga/posters/vetrolom-2013.jpg?1700349144" },
              content: "Согласен с тобой!",
              timestamp: "30 мин назад",
              likes: 1,
            },
          ]
        },
        {
          id: "1-1-1",
          user: { user_id: 1 ,name: "Мади Сахарок", avatar: "https://diabetoved.ru/upload/resize_cache/iblock/fa0/940_387_1/7ldzs3rbp7w2ynlo85kgesarwqwa15fy.jpg" },
          content: "Согласен с тобой!",
          timestamp: "30 мин назад",
          likes: 1,
       
        },
      ],
      onReply: (id, message) => console.log("Ответ на", id, message),
      onLike: (id) => console.log("Лайк на", id),
    },
    {
      id: "2",
      user: { user_id:31,name: "Иосиф Тен", avatar: "https://kstu.kg/fileadmin/user_upload/ten_i.g..jpg" },
      content: "А вот я не согласен.",
      timestamp: "2 часа назад",
      likes: 0,
      replies: [],
      onReply: (id, message) => console.log("Ответ на", id, message),
      onLike: (id) => console.log("Лайк на", id),
    },
  ];
  